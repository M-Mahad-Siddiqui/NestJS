export enum Action {
  read = 'read',
  create = 'create',
  update = 'update',
  delete = 'delete',
}
