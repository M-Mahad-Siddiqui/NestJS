export enum Resource {
  settings = 'settings',
  products = 'products',
  users = 'users',
}
